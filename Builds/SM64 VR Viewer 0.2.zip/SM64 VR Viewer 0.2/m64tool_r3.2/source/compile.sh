#!/bin/bash
dmd -ofm64tool -release @files.txt